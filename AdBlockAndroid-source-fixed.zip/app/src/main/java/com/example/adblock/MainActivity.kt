package com.example.adblock

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private var pendingVpnIntent: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var enabled by remember { mutableStateOf(false) }
            MaterialTheme {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(if (enabled) "Блокировщик включён" else "Блокировщик выключен")
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = {
                        if (!enabled) {
                            val permission = VpnService.prepare(this@MainActivity)
                            if (permission != null) {
                                pendingVpnIntent = Intent(
                                    this@MainActivity,
                                    AdBlockVpnService::class.java
                                )
                                startActivityForResult(permission, VPN_REQUEST)
                            } else {
                                startVpn()
                                enabled = true
                            }
                        } else {
                            stopService(Intent(this@MainActivity, AdBlockVpnService::class.java))
                            enabled = false
                        }
                    }) {
                        Text(if (enabled) "Остановить" else "Включить")
                    }
                }
            }
        }
    }

    private fun startVpn() {
        startService(Intent(this, AdBlockVpnService::class.java))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST && resultCode == RESULT_OK) startVpn()
    }

    companion object { private const val VPN_REQUEST = 100 }
}
