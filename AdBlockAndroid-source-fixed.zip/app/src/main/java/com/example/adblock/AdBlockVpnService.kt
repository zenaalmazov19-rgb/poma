package com.example.adblock

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

class AdBlockVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    @Volatile private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        vpnInterface = Builder()
            .setSession("AdBlock")
            .setMtu(1500)
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .establish()

        running = true
        Thread {
            vpnInterface?.fileDescriptor?.let { fd ->
                FileInputStream(fd).use { input ->
                    val buffer = ByteArray(32767)
                    while (running) {
                        try {
                            if (input.read(buffer) <= 0) continue
                            // Демонстрационный TUN-каркас.
                            // Полный packet-forwarder нужен для реальной фильтрации
                            // и чтобы не разрывать интернет-соединение.
                        } catch (_: Exception) { break }
                    }
                }
            }
        }.start()
    }

    override fun onDestroy() {
        running = false
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }
}
